Contains resources used exclusively by `ServiceLoaderTestCase`
